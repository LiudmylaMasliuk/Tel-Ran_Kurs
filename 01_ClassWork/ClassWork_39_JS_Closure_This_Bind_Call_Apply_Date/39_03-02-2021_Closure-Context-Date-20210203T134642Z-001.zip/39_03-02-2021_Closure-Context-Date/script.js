let a = 10;

function test(){
    let i = 10;
    let j = 5;
    return function(){
        console.log(i + j + a);
    }
}

a = 12;

//console.log(i);

let func = test();
func();

//let i;
for(var i = 0; i<10; i++){
    function f(j){
    setTimeout(function(){
        console.log(j);
    }, 1000);
}
f(i);
}

//console.log(i);

