/* console.log(this);

function test(){
    console.log(this);
}
test(); */

function clickHandler(){
    console.log(this);
}

//clickHandler();

/* const btn = document.querySelector('.btn');
btn.onclick = clickHandler;

let clickArrowHandler = ()=> console.log(this);
clickArrowHandler();
btn.onclick = clickArrowHandler; */

let p1 = {
    name: 'John',
    displayName: function(){
        console.log(this.name);
    }
}

p1 = {
    name: 'John',
    displayName: () =>{ 
        console.log(this);
        console.log(this.name);
    }   
}

/* let p2 = {
    name: 'Jack'
}

p2.display = p1.displayName;
p2.display(); */

p1.displayName();

/* function sum(a,b){
    return a+b;
}

const sum1 = (a,b) => a + b; */

/* let person = {
    name: 'John',
    age: 23,
    display: function(){
        console.log(this);
        console.log(this.name, this.age);
    }
}


person.display();

let print = person.display;    //function(){
                               //  console.log(this);
                              //  console.log(this.name, this.age);} 
print.apply(person);

let printPerson = print.bind(person);

printPerson(); */


function Timer(seconds){
    this.counter = seconds;

    this.tick = ()=>{
        this.counter--;
        console.log(this.counter);
    }

   /*  this.start = function(){
        //let that = this;
        setInterval(()=>{
            this.tick();
        }, 1000);
    } */
}

const timer = new Timer(20);   // {counter:20, tick: function(){counter--;}}
/* console.log(timer.counter);
timer.tick();
timer.tick();
timer.tick();
timer.tick();
console.log(timer.counter); */

//setInterval(timer.tick.bind(timer), 1000);

//timer.start();

setInterval(timer.tick, 1000);


