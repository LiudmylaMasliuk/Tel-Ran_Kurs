const now = new Date();

// console.log(now.getFullYear());
// console.log(now.getMonth());
// console.log(now.getDate());
// console.log(now.getDay());

// console.log(now.getHours());
// console.log(now.getUTCHours());

// console.log(now.getTimezoneOffset());
// console.log(now.getTime());

console.log(now.setHours(40));
console.log(now);

let start = new Date();
for(let i =0; i<100000; i++){
    let some = i ** 2;
}
let end = new Date();

console.log(`time running is ${end - start} ms`);

const endDate = new Date('2021-02-10');

const daysLeft = (endDate - new Date());

const days = Math.floor(daysLeft/(24*60*60*1000)), //24*60*60*1000  -> 10 * 24 * 60 * 60 * 1000
      hours = Math.floor((daysLeft/(60*60*1000))%24),
      minutes =Math.floor((daysLeft/(60*1000)) % 60),
      seconds = Math.floor((daysLeft/1000) % 60);

console.log(days, hours, minutes, seconds);