class Contact{
  constructor(name,lastName,address,email,phone,description){
    this.id = 0;
    this.name = name;
    this.lastName = lastName;
    this.address = address;
    this.email = email;
    this.phone = phone;
    this.description = description;
  }
}