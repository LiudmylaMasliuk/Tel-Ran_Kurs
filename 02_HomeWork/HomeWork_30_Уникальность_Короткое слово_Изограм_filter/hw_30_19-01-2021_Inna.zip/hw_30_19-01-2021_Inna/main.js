//Task01
//'hjfkds hfjd jdk shdjkg hsjshjssks shjks'
//function findShorts('hjfkds hfjd jdk shdjkg hsjshjssks shjks') -> 3 (вернуть длину самого короткого слова)

const string = 'The cat catches a mouse';

function findShort(str){
  let array = str.split(' ').map(item => item.length);
  let shortNum = array[0];
  
  array.forEach((index) => {
    if(array[index] < shortNum)
      shortNum  = array[index];
  }) 
  return shortNum;
}

console.log(findShort(string)); // --> 1

//Task02
//function isIsogram('abcd') -> true;
//function isIsogram('abbcd') -> false;
//function isIsogram('abcdA') -> false;

function isIsogram(str){
    let array = str.toLowerCase().split('');
    let checked = true;
    let letter = array[0];
    for(i = 0; i < array.length; i++){
      if(letter == array[i+1])
      checked = false;
    }
    return checked;
  }
  
  console.log(isIsogram('abacd')); // -> false
  console.log(isIsogram('abcd')); // -> true
  console.log(isIsogram('abbfA')); // -> false

//Task03
/* на вход метод получает массив чисел или строку.
    метод должен вернуть массив не повторяющихся элементов идущих по порядку. 
    напрмер:
    function uniqueElementInOrder('aaabbbcddaa') -> ['a','b','c','d','a'];
    function uniqueElementInOrder([1,2,2,3,3,4,5,5]) -> [1,2,3,4,5];
    unction uniqueElementInOrder([1,2,2,3,3,4,5,5,2,2]) -> [1,2,3,4,5,2];
    (filter использовать необязательно, но есть решение этой задачи, в которм применяется filter)
 */

function uniqueElementInOrder(input){
    if (typeof input === 'string'){
        input.split('');
    }
    let temp = [];
    for(i = 0; i < input.length; i++){
        if(input[i] !== input[i+1])
        temp.push(input[i]);
    }
     return temp;
}

console.log(uniqueElementInOrder('aaabbbcddaa')); // --> ['a','b','c','d','a']
console.log(uniqueElementInOrder([1,2,2,3,3,4,5,5])); // --> [1,2,3,4,5]
console.log(uniqueElementInOrder([1,2,2,3,3,4,5,5,2,2])); // --> [ 1, 2, 3, 4, 5, 2 ]



