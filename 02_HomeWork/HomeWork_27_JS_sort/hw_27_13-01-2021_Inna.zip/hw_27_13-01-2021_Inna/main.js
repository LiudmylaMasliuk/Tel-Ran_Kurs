// Task01 
/* 
const users = [
    {name: 'Vasya', age: 25},
    {name: 'Anna', age: 24},
    {name: 'Masha', age: 18}   // firstName
];
 Отсортировать массив users по возрасту
 */

const users = [
  {name: 'Vasya', age: 25},
  {name: 'Anna', age: 24},
  {name: 'Masha', age: 18},
];

console.log(users.sort((a,b) => a['age'] - b['age']));

//////////////////////////////////////////////////////////////////////////////////
/* Just for testing.
console.log(users[0]['name']);
console.log(users[0]['age']);
console.log(users[0 + 1]['age']); */
//////////////////////////////////////////////////////////////////////////////////



//////////////////////////////////////////////////////////////////////////////////

/*  Task02
 [1,5,8,2,4,6,9,3];
 function filterRange(3, 6) -> [3,4,5,6] */

const numbers = [1,5,8,2,4,6,9,3];

function compare(a,b){
  return a - b;
}
console.log(numbers.sort(compare).filter(item => item > 2 && item < 7));
console.log(numbers.sort(compare).slice(2,6));


//////////////////////////////////////////////////////////////////////////////////


/* Task03
отсортировать в порядке убывания [ 7,3,2,9,10 ] ->[10,9,7,3,2] */

const arrayWithNumbers = [7,3,2,9,10];

function compareNumbers(a,b){
  return a - b;
}
console.log(arrayWithNumbers .sort(compareNumbers).reverse());



