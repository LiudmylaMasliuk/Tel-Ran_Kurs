class Contact{
    constructor(name, phoneNumber, email, address, description){
        this.name = name;
        this.phone = phoneNumber;
        this.email = email;
        this.address = address;
        this.description = description;
    }
}

